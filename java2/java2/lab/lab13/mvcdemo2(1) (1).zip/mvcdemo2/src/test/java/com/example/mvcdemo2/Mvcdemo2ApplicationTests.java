package com.example.mvcdemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mvcdemo2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
